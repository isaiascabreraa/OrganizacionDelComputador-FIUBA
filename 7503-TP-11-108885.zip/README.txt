ACLARACIONES:

La matriz debe estar conformada siempre por un caracter y un espacio, lo mismo implica cuando llegamos al salto de linea, por lo que si tenemos:
"A B C D E" y queremos hacer un salto de linea para escribir debajo "F G H I K" debemos dejar un espacio entre el salto de linea y la ultima
letra de la columna para respetar el formato de lectura de la matriz, siendo que la primera linea debe ser "A B C D E " ya que tomamos dos bytes para
lectura y el salto de linea que es interpretado como un '/n' ocupa tambien 2 bytes